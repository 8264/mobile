# 移动端环境搭建
1. 利用 chrome 浏览器  deviceToolbar 来调试移动端页面的尺寸    
2. 利用本地服务器创建端口,进行真机调试.
3. 利用hbuilder等工具进行虚拟机调试 
    
